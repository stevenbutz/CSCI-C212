public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        double a = 6;
        double b = 7;
        double c = 8;
        double A = ((a*a)+(b*b)-(c*c))/(2*a*b);
        double wtf = Math.acos(1);
        System.out.println(A);
    }
}