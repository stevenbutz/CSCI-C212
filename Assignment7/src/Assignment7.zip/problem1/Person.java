package problem1;

public abstract class Person {
    public abstract String getDetails();
}
