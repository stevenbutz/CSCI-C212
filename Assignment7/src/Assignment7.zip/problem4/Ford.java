package problem4;

public class Ford extends Car {
    public Ford(int gear, int speed, int mileage) {
        super(gear, speed, mileage);
    }
}
