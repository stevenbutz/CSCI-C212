package problem4;

public class Volkswagen extends Car {
    public Volkswagen(int gear, int speed, int mileage) {
        super(gear, speed, mileage);
    }
}
