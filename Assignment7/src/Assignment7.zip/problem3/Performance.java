package problem3;

public interface Performance {
    double getPerformance();
}
